# config.py

LOCAL_DB_CONFIG = {
    "dbname": "macspot",
    "user": "danielkallberg",
    "password": "HittaFitta69",
    "host": "localhost",
    "port": 5433
}

REMOTE_DB_CONFIG = {
    "dbname": "postgres",
    "user": "daniel",
    "password": "wijmeg-zihMa7-gomcuq",
    "host": "macspotpg.postgres.database.azure.com",
    "port": 5432
}